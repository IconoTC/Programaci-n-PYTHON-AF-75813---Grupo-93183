''' Crear una excepcion personalizada '''

# Version minima
#class NegativoError(Exception):
#    pass

class NegativoError(Exception):
    def __init__(self, msg):
        self.message = msg
        
    def getMessage(self):
        return self.message
'''   
try:   
    edad = int(input("Introduce tu edad: "))
    if edad < 0:
        # Las exepciones personalizadas siempre se lanzan de forma manual
        raise NegativoError("La edad no puede ser negativa")
except NegativoError as ex:
    print(ex.getMessage())
''' 
    
def solicitar_edad(): 
    edad = int(input("Introduce tu edad: "))
    if edad < 0:
        # Las exepciones personalizadas siempre se lanzan de forma manual
        raise NegativoError("La edad no puede ser negativa")
    return edad

try:
    solicitar_edad()
except NegativoError as ex:
    print(ex.getMessage())
# try-except-else-finally

import traceback
try:
    numero1 = int(input("Introduce dividendo: "))
    numero2 = int(input("Introduce divisor: "))
    division = numero1 / numero2
except ValueError as e:
    print("El valor introducido no es numerico")
    print(e) # invalid literal for int() with base 10: 'hbjhgvbhkgv'
    traceback.print_exc() # Muestra la pila de llamadas
except ZeroDivisionError as ex:
    print("No se puede dividir por cero")
    print(ex)
    traceback.print_exc() # Muestra la pila de llamadas
except Exception as pepito:
    print("Ha ocurrido un error")
    print(pepito)
    traceback.print_exc() # Muestra la pila de llamadas
else:
    # Se ejecuta cuando no hay ningun error
    print("Resultado:", division)
finally:
    # Siempre se ejecuta, haya error o no
    print("*** FIN ***")
    
''' Estructuras minimas que funcionan '''
try:
    pass
except:
    pass

try:
    pass
finally:
    pass

''' Esto no funciona 
try:
    pass
else:
    pass
'''
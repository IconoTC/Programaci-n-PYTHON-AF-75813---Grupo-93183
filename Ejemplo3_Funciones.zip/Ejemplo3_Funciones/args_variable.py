def sumar(*numeros):
    # print(type(numeros)) # <class 'tuple'>
    suma = 0
    for num in numeros:
        suma += num
    return suma
    
print(sumar()) 
print(sumar(9))
print(sumar(9, 5))
print(sumar(9, 3, 7))


'''
    crear la funcion procesar_notas que recibe el nombre y las notas del alumno
    cada alumno esta matriculado en diferentes asignaturas
    utilizando la funcion sumar() calcular la nota media
    devolver el nombre en mayusculas y la nota media
'''

def procesar_notas(nombre, *notas):
    # sumar(notas) estoy enviando una tupla de datos
    # sumar(*notas) estoy enviando el contenido de la tupla
    nota_media = sumar(*notas) / len(notas)
    return nombre.upper(), nota_media

print(procesar_notas('Juan', 2,5,3))
print(procesar_notas('Maria', 9,8))
print(procesar_notas('Pedro', 10,5,7,4))
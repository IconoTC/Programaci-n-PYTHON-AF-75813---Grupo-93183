'''
    Crear una funcion que recibe un texto y retorna:
        - el texto en mayusculas
        - el texto en minusculas
        - la longitud del texto
'''

def procesar_texto(texto: str):
    mayusculas = texto.upper()
    minusculas = texto.lower()
    longitud = len(texto)
    return mayusculas, minusculas, longitud

# Recuperar con multiples variables
txt_may, txt_min, len_txt = procesar_texto("Hola, que tal?")
print(txt_may)
print(txt_min)
print(len_txt)

# Recuperar con una coleccion de tipo tupla
tupla = procesar_texto("Hola, que tal?")
print(tupla)
for dato in tupla:
    print(dato)
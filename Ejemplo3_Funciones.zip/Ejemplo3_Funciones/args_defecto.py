def datos_trabajador(nombre, estado_civil="Soltero", sueldo=24000):
    print(nombre, "esta", estado_civil, "y gana", sueldo)
    
datos_trabajador("Maria")
# Cuando tenemos mas de un argumento por defecto, hay que utilizar keywords
datos_trabajador("Juan", 35000) # por posicion  Juan esta 35000 y gana 24000
datos_trabajador(nombre="Juan", sueldo=35000) # por keywords
datos_trabajador(sueldo=35000, nombre="Juan") # por keywords podemos cambiar el orden

'''
    Crear una funcion concatenar que recibe:
        - datos de tipo str como numero variable de argumentos
        - separador que por defecto sera " | "
    y retorne los datos unidos con el separador en una cadena de texto  separador.join(datos)
'''

# En la combinacion: argumentos variables y por defecto
# El orden es este
def concatenar(*datos: str, separador=" | "):
    return separador.join(datos)

print(concatenar('a','e','i','o','u'))
print(concatenar('a','e','i','o','u', separador=", "))
print(concatenar('a','e','i','o','u', separador=" "))
print(concatenar('a','e','i','o','u', separador=" - "))

# No se puede inteercambiar el orden con keywords
# print(concatenar(separador=" - ", datos='a','e','i','o','u'))
import pickle

# Abrir el fichero en modo lectura y binario
fichero = open("Ejemplo12_Ficheros_Binarios/fichero.bin", "rb")

# Leer el contenido
frutas = pickle.load(fichero)

# Mostrar el contenido y tipo
print(frutas)
print(type(frutas)) # <class 'set'>

# Cerrar el fichero
fichero.close()
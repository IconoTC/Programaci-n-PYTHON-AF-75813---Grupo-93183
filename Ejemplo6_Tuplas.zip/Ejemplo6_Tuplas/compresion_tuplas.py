# Ejemplo 1
# crear una tupla con el cuadrado de cada numero
numeros = (1,2,3,4,5)

# En las tuplas en necesario tuple() para crearla, sino entiende que es un generador
tupla_cuadrados = (num ** 2  for num in numeros)
print(tupla_cuadrados) # <generator object <genexpr> at 0x102b5cee0>

tupla_cuadrados = tuple(num ** 2  for num in numeros)
print(tupla_cuadrados) # (1, 4, 9, 16, 25)


# Ejemplo 2
# crear una tupla con pares (dia, longitud) de los dias que comienzan por m 
# ( ('martes', 6), ('miercoles', 9) )
dias = ('lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado', 'domingo')
tupla_dias = tuple( (dia, len(dia)) for dia in dias if dia[0]=='m')
tupla_dias = tuple( (dia, len(dia)) for dia in dias if dia.startswith('m'))
print(tupla_dias)
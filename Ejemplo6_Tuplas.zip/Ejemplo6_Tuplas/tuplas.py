# tuplas: Colecciones ordenadas (con indice) pero inmutables
# se permiten elementos repetidos
# Pueden ser elementos de diferentes tipos
# Se crean con ()
# Ejemplos: dias de la semana, meses del año, estado civil, puntos cardinales, ...

# tuplas de varias dimensiones tambien funcionan
# slices funcionan igual que las listas
# operadores de pertenencia: in y not in

dias = ('lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado', 'domingo')
print(type(dias)) # <class 'tuple'>
print(dias)

# crear una tupla vacia
tupla_vacia = ()
tupla_vacia = tuple() # llamar al constructor de la clase tuple

# Recorrer por item
for item in dias:
    print(item, end=" ")
print()

# Recorrer por indice
for idx in range(len(dias)):
    print(dias[idx], end=" ")
print()

# Intento borrar el lunes
#del dias[0] # TypeError: 'tuple' object doesn't support item deletion

# Concatenar tuplas en otra tupla
numeros = (1,2,3,4,5)
otra_tupla = dias + numeros
print(otra_tupla)

# Para concatenar tuplas, la tupla ha de tener mas de un elemento
# TypeError: can only concatenate tuple (not "str") to tuple
#mas_dias = dias + ('sabado')
#mas_dias = dias + ('sabado', 'domingo') # Funciona
mas_dias = dias + ('sabado',) # le engañamos al interprete de python para que piense que hay mas de un elemento
print(mas_dias)

# longitud de la tupla
print("Longitud", len(mas_dias))
print("Longitud", mas_dias.__len__())

print("Cuantos sabados hay?", mas_dias.count("sabado"))

# En que indice esta el viernes
print("Indice viernes:", mas_dias.index("viernes"))
#print("Indice viernes:", mas_dias.index("viernessssssss")) # ValueError: tuple.index(x): x not in tuple

# Otra forma de crear tuplas
tupla = 1,2,3,4,5
print(type(tupla)) # <class 'tuple'>

# Duplicar o triplicar, .... los elementos de la tupla
# Tambien se puede hacer con listas
resultado = tupla * 2 
print(resultado) # 1, 2, 3, 4, 5, 1, 2, 3, 4, 5)

# Tambien funciona con listas
print("Minimo:", min(tupla))
print("Maximo:", max(tupla))
print("Suma:", sum(tupla))

# Convertir una tupla en lista
lista_dias = list(dias)
print(lista_dias)
print(type(lista_dias)) # <class 'list'>

# Convertir una lista en tupla
nueva_tupla = tuple(lista_dias)
print(nueva_tupla)
print(type(nueva_tupla))
'''
    Comentarios de Bloque (Docstring)
    3 comillas simples o dobles
    Ejemplo de tipos de datos en Python
'''

# numeros enteros <class 'int'>
numero1 = 8
# Numero1 = 9 Python es case sentisitive y diferencia mayusculas de minusculas, estoy creando nueva variable
numero2 = 4
suma = numero1 + numero2
print(type(suma))
print(suma)
# TypeError: can only concatenate str (not "int") to str
# La concatenacion en Python solo se permite entre cadenas de texto
# print("Suma:" + suma)
print("Suma: " + str(suma))   # convertimos suma a tipo string
print("Suma:", suma)


# numeros reales <class 'float'>
base = 4.89
altura = 9.23
triangulo = base * altura / 2
print(type(triangulo))
   # print("Area del triangulo:", triangulo) # IndentationError: unexpected indent
print("Area del triangulo:", triangulo)


# booleanos: True o False <class 'bool'>
soltero = True
print("Estas soltero?", soltero)
print(type(soltero))


# cadenas de texto <class 'str'>
# se pueden utilizar comillas dobles o simples
nombre = "Juan"
apellido = 'Lopez'
print(nombre, apellido)
print(nombre + " " + apellido)
print(type(nombre))
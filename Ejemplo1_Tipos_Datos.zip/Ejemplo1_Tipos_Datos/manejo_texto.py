# Consultar la clase str
# https://python-docs-es.readthedocs.io/es/3.14/library/stdtypes.html#text-sequence-type-str

# En Python de forma optativa podemos establecer el tipo de dato
# Si no lo hacemos, el interprete funciona con inferencia de tipos
texto: str = "bienvenidos al curso de Python"

print(texto.capitalize()) # Solo la primera letra en mayusculas y el resto en minusculas
print(texto.title()) # Mayuscula la primera letra de cada palabra
print(texto.upper()) # Todo en mayusculas
print(texto.lower()) # Todo en minusculas
print(texto.swapcase()) # intercambia mayusculas por minusculas y viceversa

print("isalnum", texto.isalnum()) # Sera True si solo hay letras y numeros, False por los espacios en blanco
print("isalnum", '12345'.isalnum()) # True
print("isalnum", 'hola'.isalnum()) # True
print("isalnum", 'hola12345'.isalnum()) # True

print("isalpha", texto.isalpha())  # Sera True si solo hay letras, False por los espacios en blanco
print("isalpha", '12345'.isalpha()) # False
print("isalpha", 'hola'.isalpha()) # True
print("isalpha", 'hola12345'.isalpha()) # False

print("isdigit", texto.isdigit())  # Sera True si solo hay numeros, False por los espacios en blanco y letras
print("isdigit", '12345'.isdigit()) # True
print("isdigit", 'hola'.isdigit()) # False
print("isdigit", 'hola12345'.isdigit()) # False

print("isupper", texto.isupper())  # True si solo hay mayusculas, ignora el resto numeros, espacios, caracteres especiales,  False
print("isupper", '12345'.isupper()) # False
print("isupper", 'hola'.isupper()) # False
print("isupper", 'HOLA'.isupper()) # True
print("isupper", 'HOLA12345'.isupper()) # True
print("isupper", 'HOLA 12345'.isupper()) # True
print("isupper", 'HOLA_12345'.isupper()) # True

print("islower", texto.islower())  # True si solo hay minusculas, ignora el resto numeros, espacios, caracteres especiales,  False
print("islower", '12345'.islower()) # False
print("islower", 'hola'.islower()) # True
print("islower", 'HOLA'.islower()) # False
print("islower", 'hola12345'.islower()) # True
print("islower", 'hola 12345'.islower()) # True
print("islower", 'hola_12345'.islower()) # True

print("Longitud:", len(texto)) # Numero de caracteres de la cadena de texto

# La tabla ASCII esta ordenada (1º caracteres especiales, 2º numeros, 3º mayúsculas, 4º minusculas)
print("Max:", max(texto)) # y El caracter con mayor valor en la tabla ASCII
print("Min:", min(texto)) # el espacio en blanco

ejemplo = "      Hoy es lunes      "
print(ejemplo, end=".\n")
print("lstrip", ejemplo.lstrip(), end=".\n") # Eliminamos espacios por la izquierda
print("rstrip", ejemplo.rstrip(), end=".\n") # Eliminamos espacios por la derecha
print("strip", ejemplo.strip(), end=".\n") # Eliminamos espacios por la izquierda y derecha

print("strip", '.....hola......'.strip('.'), end=".\n")

print("replace", texto.replace("Python", "Angular"))
print("replace", texto.replace("e", "E"))  # Reemplaza todas 
print("replace", texto.replace("e", "E", 1)) # Reemplaza solo la primera letra e que encuentra

palabras = texto.split() # Trocea una cadena en subcadenas por el espacio en blanco
print(type(palabras)) # <class 'list'>
print(palabras)  # ['bienvenidos', 'al', 'curso', 'de', 'Python']

fecha = "2/3/2026".split("/")
print(fecha) # ['2', '3', '2026']

# Los indices siempre empiezan en 0
print("find", texto.find('o')) # 9 indice donde encuentra la primera letra o
print("rfind", texto.rfind('o')) # 28 empieza a buscar por la derecha
print("find", texto.find('z')) # -1 cuando el caracter no existe
print("find", texto.find('o', 10)) # 19 empieza a buscar a partir del indice 10
print("find", texto.find('o', 10, 19)) # -1 porque busca entre el indice 10 y el 18.  El ultimo no esta incluido
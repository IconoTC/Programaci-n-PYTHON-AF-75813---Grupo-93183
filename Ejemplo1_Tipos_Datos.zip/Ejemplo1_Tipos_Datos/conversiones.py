import math

# convertir de texto a numero entero
dato = input("Introduce un numero: ")
print(type(dato))   # <class 'str'>
numero1 = int(dato)
print(type(numero1))   # <class 'int'>
numero2 = int(input("Introduce otro numero: "))
print("Suma:", numero1 + numero2)

# ValueError: invalid literal for int() with base 10: '10.34'
# ValueError: invalid literal for int() with base 10: 'dos'
# probar 10.34  o  'dos'


# convertir de texto a numero real
radio = float(input("Introduce el radio del circulo: "))
print("Area del circulo:", math.pi * math.pow(radio, 2))
print("Area del circulo:", math.pi * radio ** 2) # ** potencia
# round(que?, num_decimales)
print("Area del circulo:", round(math.pi * math.pow(radio, 2), 2))

# probar 10,34  o  'dos' o 5
# ValueError: could not convert string to float: '10,34'
# ValueError: could not convert string to float: 'dos'
# 5 si funciona, lo convierte a 5.0


# convertir numero a booleano
# 0 -> False, 1 -> True
# 0 es el unico caso que lo convierte a False, todo lo demas (1, "hola", 5.34) es True
soltero = 0
print("Estas soltero?", bool(soltero))

# convertir a texto
print(str(numero1) + str(numero2))
print(str(soltero))
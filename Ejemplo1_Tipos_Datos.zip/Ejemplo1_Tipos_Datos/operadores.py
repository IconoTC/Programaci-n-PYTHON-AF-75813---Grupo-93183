# Operadores aritmeticos
numero1 = 7
numero2 = 2
print("Suma:", numero1 + numero2)
print("Resta:", numero1 - numero2)
print("Multiplicacion:", numero1 * numero2)
print("Division:", numero1 / numero2)
print("Divison entera:", numero1 // numero2)
print("Resto o modulo de la division:", numero1 % numero2)
print("Potencia:", numero1 ** numero2)


# Operadores de asignacion
numero1 += 5   # numero1 = numero1 + 5

# En Python no existen incrementos ni decrementos
numero1 += 1  # numero1++
numero1 -= 1  # numero1--


# Operadores relaccionales
print(numero1 > numero2) # True
print(numero1 >= numero2) # True
print(numero1 == numero2) # False
print(numero1 != numero2) # True


# Operadores logicos
print("and", numero2 == 2 and numero1 > 0) # True
print("and", numero2 == 5 and numero1 > 0) # False
print("or", numero2 == 5 or numero1 > 0) # False
print(numero2 == 5) # False
print("not", not numero2 == 5) # True


# Operadores de identidad (is, is not)
# Sirven para verificar si es el mismo objeto
num1 = 6
num2 = 6
print("Es el mismo objeto", num1 is num2) # True

nombre1 = "Pepito"
nombre2 = "Pepito"
print("Es el mismo objeto", nombre1 is nombre2) # True

lista1 = ['Juan', 'Maria']
lista2 = ['Juan', 'Maria']
print("Es el mismo objeto", lista1 is lista2) # False
print("No es el mismo objeto", lista1 is not lista2) # True


# Operadores de pertenencia (in, not in)
print("Luis esta en lista1", 'Luis' in lista1 ) # False
print("Luis no esta en lista1", 'Luis' not in lista1 ) # True
print("Juan esta en lista1", 'Juan' in lista1 ) # True

# Las cadenas de texto son colecciones de caracteres
print("La e esta en Pepito", 'e' in 'Pepito') # True
print("La j esta en Pepito", 'j' in 'Pepito') # False
print("La j no esta en Pepito", 'j' not in 'Pepito') # True

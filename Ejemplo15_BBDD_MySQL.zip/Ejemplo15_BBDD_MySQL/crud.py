# pip install mysql-connector-python   instalamos el driver de MySQL
import mysql.connector

# Abrir la BBDD
conexion = mysql.connector.connect(
    host="localhost",
    user="root",
    password="rootroot",
    database="tienda"
)

# Obtener el cursor, necesario para ejecutar querys y recoger resultados
cursor = conexion.cursor()

''' ************************* Insert  *************************** '''
cursor.execute("insert into PRODUCTOS values (1, 'Teclado', 35.60)")
cursor.execute("insert into PRODUCTOS values (2, 'Raton', 20.95)")

coleccion = [[3, 'Pantalla', 129.50],  # elimentos han de ser lista o tupla
             [4, 'Scanner', 450],
             [5, 'Impresora', 89.90]]
sql = "insert into PRODUCTOS values (%s, %s, %s)" # Query parametrizada
cursor.executemany(sql,coleccion)

conexion.commit()


''' ************************* Consultas  *************************** '''
# consultar todos los productos
cursor.execute("select * from PRODUCTOS")

# recoger todos los resultados de la query
lista = cursor.fetchall()
for prod in lista:
    #print(type(prod)) # <class 'tuple'>
    print(prod)
print("----------------------")

# consultar todos los productos con precio inferior a 50
cursor.execute("select * from PRODUCTOS where precio < 50")
for prod in cursor.fetchall():
    print(prod)
print("----------------------")

# consultar todos los productos que la descripcion sea Impresora
parametros = ['Impresora']
cursor.execute("select * from PRODUCTOS where descripcion = %s", parametros)
prod = cursor.fetchone()
print(prod)
print("----------------------")

# consultar todos los productos ordenados por el precio
cursor.execute("select * from PRODUCTOS ORDER BY precio")
for prod in cursor.fetchall():
    print(prod)
print("----------------------")

# consultar todos los productos ordenados por el precio descendente
cursor.execute("select * from PRODUCTOS ORDER BY precio DESC")
for prod in cursor.fetchall():
    print(prod)
print("----------------------")

# consultar todos los productos que comienzan por la letra R
parametros = ('R%',) # engañamos al interprete de Python para que crea que hay varios elementos
cursor.execute("select * from PRODUCTOS where descripcion LIKE %s", parametros)
for prod in cursor.fetchall():
    print(prod)
print("----------------------")

# consultar todos los productos que contienen la letra e y el precio sea inferior a 200
parametros = ('%e%', 200) 
cursor.execute("select * from PRODUCTOS where descripcion LIKE %s and precio < %s", parametros)
for prod in cursor.fetchall():
    print(prod)
print("----------------------")

''' ************************* Modificar  *************************** '''
# subir un 10% el precio de la impresora
parametros = ('Impresora',)
cursor.execute('update PRODUCTOS set precio = precio * 1.1 where descripcion = %s', parametros)
conexion.commit()

# cambiar la descripcion de raton a raton inalambrico
parametros = ('Raton inalambrico','Raton')
cursor.execute('update PRODUCTOS set descripcion = %s where descripcion = %s', parametros)
conexion.commit()

''' ************************* Eliminar  *************************** '''
# Eliminar todos los Scanner
cursor.execute('delete from PRODUCTOS where descripcion = %s', ['Scanner'])
conexion.commit()

# Cerrar la BBDD
conexion.close()
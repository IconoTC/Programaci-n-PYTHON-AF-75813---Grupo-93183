import csv

with open('Ejemplo13_Ficheros_CSV/productos.csv', 'w', newline="") as productos:
    cabeceras = ['ID', 'Descripcion', 'Precio']
    writer = csv.DictWriter(productos, fieldnames=cabeceras, delimiter=";")
    writer.writeheader()  # Escribir las cabeceras
    writer.writerow({'ID':1, 'Descripcion':'Pantalla', 'Precio':129.50})
    writer.writerow({'ID':2, 'Descripcion':'Teclado', 'Precio':49.95})
    writer.writerow({'ID':3, 'Descripcion':'Raton', 'Precio':18})
    writer.writerow({'ID':4, 'Descripcion':'Scaner', 'Precio':450})
    writer.writerow({'ID':5, 'Descripcion':'Impresora', 'Precio':89.90})
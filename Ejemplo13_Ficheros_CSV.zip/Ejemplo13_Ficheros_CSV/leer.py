import csv

with open('Ejemplo13_Ficheros_CSV/productos.csv', 'r', newline="") as productos:
    # Leer todo el contenido de golpe
    datos = csv.reader(productos, delimiter=";")
    print(type(datos)) # <class '_csv.reader'>
    for item in datos:
        print(item) # lista
        
with open('Ejemplo13_Ficheros_CSV/productos.csv', 'r', newline="") as productos:
    # Leer todo el contenido de golpe
    datos = csv.DictReader(productos, delimiter=";")
    print(type(datos)) # <class 'csv.DictReader'>
    for item in datos:
        print(item) # diccionario
        print("ID:", item['ID'])
        print("Descripcion:", item['Descripcion'])
        print("Precio:", item['Precio'])
        print("-------------------------")
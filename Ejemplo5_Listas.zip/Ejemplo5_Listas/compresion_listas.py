# Ejemplo 1
# se trata de crear otra lista con la longitud de cada palabra que tenga mas de 6 caracteres
lista_palabras = ['casa', 'tunel', 'manzana', 'ayuntamiento']
longitud_palabras = []

for palabra in lista_palabras:
    if len(palabra) > 6:
        longitud_palabras.append(len(palabra))
print(longitud_palabras)

''' compresion de listas '''
longitud_palabras = [len(palabra) for palabra in lista_palabras if len(palabra) > 6]
print(longitud_palabras)

# Ejemplo 2
# crear una lista con los numeros pares del 0 al 10 (range)
num_pares = [num for num in range(0,11,2)]
print(num_pares)
num_pares = [num for num in range(0,11) if num % 2 == 0]
print(num_pares)

# Ejemplo 3
# crear otra matriz de 2 dimensiones con los numeros impares
# matriz_impares = [ [7], [3,9,5], [1] ]
matriz = [ [2,7,4], [3,9,5], [8,1,6] ]
matriz_impares = [ [num for num in fila if num % 2 != 0 ] for fila in matriz ]
print(matriz_impares)
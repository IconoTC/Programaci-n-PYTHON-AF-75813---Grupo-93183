# listas: colecciones ordenadas de elementos (tienen indice)
# en todas las colecciones los elementos pueden ser de diferente tipo
# permite elementos duplicados
# son mutables: permite modificar, agregar y eliminar elementos
# Se crean con []

list1 = ['Maria', 'Perez', 30, 'soltera', 'sin hijos']
list2 = ['estudiante', 'medicina', 28010]
print(list1)
print( type(list2)) # <class 'list'>

# crear una lista vacia
lista_vacia = []
lista = list() # invocando al constructor de la clase list

# unir listas
lista = list1 + list2 # el orden es importante
print(lista)
lista = list2 + list1
print(lista)

# longitud de la lista
print("Longitud:", len(lista))
print("Longitud:", lista.__len__())

# Acceso a los elementos de la lista
# indice positivo comienza por el primero 0, por la izquierda
print(lista[2])  # siempre el indice entre [] sea lista, tupla, diccionario
# indice negativo comienza por el ultimo -1, por la derecha
print(lista[-2]) # 8 - 2 = 6

# Agregar elementos al final -> append
lista.append("morena")
print(lista)

# Agregar elementos en una determinada posicion -> insert
lista.insert(0, 1.70)
print(lista)

# Agregar varios elementos a la vez -> extend  siempre van al final
lista.extend({1,2,3}) # los elementos han de ir en una coleccion lista, tupla o conjunto
print(lista)

# Eliminar elementos por indice
del lista[0]  # Borra el primer elemento, el que esta en el indice 0
print(lista)

# Eliminar elementos por busqueda
lista.remove(3) # Busca el valor 3 y el primero que encuentra lo elimina
print(lista)

# Buscar un elemento y me retorna el indice donde se enecuentra
indice = lista.index('Perez') # 4
print(indice)
# indice = lista.index('Perezzzzzzzz') # ValueError: list.index(x): x not in list

# Mostrar cuantas soltera hay
print("Numero soltera:", lista.count('soltera'))

# Invertir la lista
lista.reverse()
print(lista)

# Ordenar listas
colores = ['rojo', 'verde', 'azul', 'amarillo']
print(sorted(colores)) # muestra la lista ordenada pero no la modifica
print(colores)

colores.sort() # ordena la lista y la modifica
print(colores)

# Ordenar la lista de forma descendente
print(sorted(colores, reverse=True))
colores.sort(reverse=True)

# Por defecto, al ser texto lo ordena de forma alfabetica
# Con el parametro key queremos cambiar el orden (la longitud del texto)
def ordenar(dato):
    return len(dato)

print(sorted(colores, key=ordenar))
print(sorted(colores, key=lambda dato: len(dato)))
print(sorted(colores, key=lambda dato: len(dato), reverse=True))

# Eliminar todos los elementos de la lista
colores.clear()
print(colores)

''' slices [begin:stop:step]  '''
# mostrar todos los elementos de la lista
print("Todos:", lista[:])

# mostrar los elementos del indice 3 al indice 6
print("Del indice 3 al 6:", lista[3:7])

# mostrar los ultimos 4 elementos
print("Ultimos 4:", lista[-4:])

# mostrar los elementos del indice 6 al indice 3
print("Del indice 6 al 3:", lista[6:2]) # lista vacia
print("Del indice 6 al 3:", lista[6:2:-1])

# mostrar todos los elementos de la lista en orden inverso
print("Todos inverso:", lista[::-1])

# mostrar todos los elementos de la lista en orden inverso de 2 en 2
print("Todos inverso de 2 en 2:", lista[::-2])
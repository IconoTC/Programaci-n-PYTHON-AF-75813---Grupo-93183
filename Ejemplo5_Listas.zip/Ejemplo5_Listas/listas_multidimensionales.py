# listas de 2 dimensiones
matriz = [ [2,7,4], [3,9,5], [8,1,6] ] # 2 indices [fila][columna]

'''
    2 7 4
    3 9 5
    8 1 6
'''

# Necesitamos 2 bucles para recorrer la matriz
for fila in matriz:
    for num in fila:
        print(num, end=" ")
    print()
    
    
# Matrices no cuadradas, cada fila tiene diferente numero de columnas
matriz2 = [ [2,7,4,1], [3,9,5,6,0], [8,1] ]

for fila in matriz2:
    for num in fila:
        print(num, end=" ")
    print()
    
for idx_fila in range(len(matriz2)):
    for idx_col in range(len(matriz2[idx_fila])):
        print(matriz2[idx_fila][idx_col], end=" ")
    print()
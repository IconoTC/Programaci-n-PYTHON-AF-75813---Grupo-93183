'''
    podemos importar el modulo completo con alias:   import persona as p
    podemos importar un recurso con alias:   from persona import Persona as Person
    ya no podemos utilizar el nombre del modulo o recurso, siempre ha de ser el alias
'''
# alias.recurso 
# alias

from persona import Persona as Person

juan = Person("Juan", 19)
print(juan)


''' importar el modulo completo y asi podemos acceder a todos los recursos '''
# modulo.recurso

import persona

luis = persona.Persona("Luis", 48)
print(luis)

persona.prueba()
''' si solo importo un recurso del modulo, no tengo acceso al resto de recursos '''
# recurso

from persona import Persona

maria = Persona("Maria", 34)
print(maria)

# No puedo acceder a la funcion prueba()
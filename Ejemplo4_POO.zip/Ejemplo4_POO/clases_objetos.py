class Persona:
    #pass # significa que el cuerpo esta vacio
   
    # constructor o inicializador
    def __init__(self, nombre: str, edad: int) -> None:
        # crear propiedades, atributos, campos del objeto 
        self.nombre = nombre
        self.edad = edad
        
    # Si el metodo recibe como argumento el puntero self se considera un metodo de instancia
    def mostrar_info(self):
        # Necesitamos el puntero self para acceder a los recursos de la instancia
        #print("Me llamo", self.nombre, "y tengo", self.edad, "años")
        print("Me llamo {} y tengo {} años".format(self.nombre, self.edad))



p1 = Persona("Juan", 23)
print(p1) # <__main__.Persona object at 0x1049546e0>
p1.mostrar_info()

# Los atributos o propiedades son publicas
p1.edad += 1
p1.mostrar_info()


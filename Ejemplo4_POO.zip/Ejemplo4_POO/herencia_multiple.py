class Animal:
    def __init__(self, nombre: str, edad: int) -> None: 
        self.__nombre = nombre
        self.__edad = edad
        
    def __str__(self):
        return "Nombre: {} Edad: {}".format(self.__nombre, self.__edad)
    
class ProductoVenta:
    def __init__(self, codigo, precio):
        self.__codigo = codigo
        self.__precio = precio
        
    def __str__(self):
        return "Codigo: {} Precio: {}".format(self.__codigo, self.__precio)
    
class Perro(Animal, ProductoVenta):
    def __init__(self, nombre, edad, codigo, precio, vacunado, sexo):
        # En herencia multiple no utilizo super() sino el nombre de la clase
        # y es necesario pasar como parametro el puntero self
        Animal.__init__(self, nombre, edad)
        ProductoVenta.__init__(self, codigo, precio)
        self.__vacunado = vacunado
        self.__sexo = sexo
        
    def __str__(self):
        return "{} {} Vacunado: {} Sexo: {}".format(
                Animal.__str__(self), ProductoVenta.__str__(self), self.__vacunado, self.__sexo                                    
        )  
        
perro = Perro("Fifi", 3, "PE-001", 295.90, True, "Macho")
print(perro)
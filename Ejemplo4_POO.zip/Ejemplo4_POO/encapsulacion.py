# Una clase encapsulada define sus propiedades como privadas
# y se accede a ellas a través de los métodos get y set publicos
class Fecha:
    def __init__(self, dia, mes, anyo) -> None:
        # Mala practica, porque no comprobamos el dia
        #self.__dia = dia
        self.setDia(dia)
        self.setMes(mes)
        self.setAnyo(anyo)
        
    def getDia(self):
        return self.__dia
    
    def setDia(self, dia):
        # los dias son validos del 1 al 31
        if dia > 0 and dia <= 31:
            self.__dia = dia
        else:
            self.__dia = 0
            
    def getMes(self):
        return self.__mes
    
    def setMes(self, mes):
        if mes >= 1 and mes <= 12:
            self.__mes = mes
        else:
            self.__mes = 0
            
    def getAnyo(self):
        return self.__anyo
    
    def setAnyo(self, anyo):
        # los años validos son 2026 y 2027
        if anyo == 2026 or anyo == 2027:
            self.__anyo = anyo
        else:
            self.__anyo = 0
        
    def __str__(self) -> str:
        return "{}/{}/{}".format(self.__dia, self.__mes, self.__anyo)
    
hoy = Fecha(376556,398,-2026)
print(hoy)

hoy = Fecha(3,3,2026)
print(hoy)

# cambiar la fecha a mañana
#hoy.__dia = 4.  # No cambia la fecha, acabamos de crear nueva propiedad en el objeto hoy
hoy.setDia(4)
print(hoy)

# Mostrar el dia
#print("Dia:", hoy.__dia) # AttributeError: 'Fecha' object has no attribute '__dia'
hoy._Fecha__dia = 5
print("Dia:", hoy._Fecha__dia) # mangling.  NO es recomendable su uso
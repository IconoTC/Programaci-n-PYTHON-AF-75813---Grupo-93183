class Persona:
    def __init__(self, nombre: str, edad: int) -> None: 
        self.nombre = nombre
        self.edad = edad
        
    def __str__(self):
        return "Me llamo {} y tengo {} años".format(self.nombre, self.edad)

class Empleado(Persona):
    def __init__(self, nombre, edad, sueldo):
        # Enviamos el nombre y la edad al constructor de la superclase  
        super().__init__(nombre, edad)
        self.sueldo = sueldo
        
    def __str__(self):
        # super().__str__() llama al __str__ de la superclase
        return "{}, sueldo {}".format(super().__str__(), self.sueldo)
        
class Jefe(Empleado):
    def __init__(self, nombre, edad, sueldo, bonus):
        super().__init__(nombre, edad, sueldo)
        self.bonus = bonus
        
    def __str__(self):
        # return "{}, bonus {}".format(super().__str__(), self.bonus)
        # Cuando utilizo el nombre de la clase en vez de super() es obligatorio pasar el puntero self
        return "{}, bonus {}".format(Empleado.__str__(self), self.bonus)
    
# Crear objetos o instancias
empl1 = Empleado("Juan", 23, 35000)
print(empl1)  # __str__ de Empleado

jefe = Jefe("Jorge", 35, 50000, 12000)
print(jefe) # __str__ de Jefe
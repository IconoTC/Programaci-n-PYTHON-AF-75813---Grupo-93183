'''
    Leer la informacion de fichero.txt y generar una copia.txt
    mostrar el contenido copia.txt
'''

# Abrir el fichero en modo lectura
fichero_lectura = open("Ejemplo11_Ficheros_Texto/fichero.txt", "rt", encoding="utf-8")

# Abrir el fichero en modo lectura y escritura
fichero_escritura = open("Ejemplo11_Ficheros_Texto/copia.txt", "w+t", encoding="utf-8")

# Leer el contenido del fichero en una lista
contenido = fichero_lectura.readlines()

# Recorro la lista y por cada linea la escribo en copia.txt
for linea in contenido:
    fichero_escritura.write(linea)
    
# leer copia.txt
fichero_escritura.seek(0)
for linea in list(fichero_escritura):
    print(linea, end="")
    
# cerrar ambos ficheros
fichero_lectura.close()
fichero_escritura.close()
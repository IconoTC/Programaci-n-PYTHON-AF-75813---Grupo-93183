# https://pandas.pydata.org/docs/reference/index.html#api

import pandas as pd

# Crear una serie de nombres
data = ['Juan', 'Pedro', 'Estefania', 'Ana', 'Esteban']
serie = pd.Series(data, dtype="string")
print(serie)

# propiedades o atributos
print("Longitud:", serie.size) # 5
print("Indices:", serie.index) # RangeIndex(start=0, stop=5, step=1)

# acceso a los elementos
print(serie[3]) # Ana
print(serie[-3:]) # los 3 ultimos
print(serie[0:2]) # los 2 primeros
print(serie[::-1]) # todos en orden descendente
print(serie[ [1,3] ]) # Pedro y Ana
#print(serie[9]) # KeyError: 9 si no existe ese indice

# aplicar una funcion o lambda a una serie
# genera una nueva serie con los elementos modificados
mayusculas = serie.apply(lambda nombre: nombre.upper())
print(mayusculas)

# si queremos que modifique la serie original
def procesar_nombre(nombre):
    return nombre.upper()

serie = serie.apply(procesar_nombre) # procesa_nombre() estas llamando a la funcion y necesitas 1 argumento
print(serie)

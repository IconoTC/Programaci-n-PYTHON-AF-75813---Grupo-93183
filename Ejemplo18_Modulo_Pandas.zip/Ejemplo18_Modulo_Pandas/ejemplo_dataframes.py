import pandas as pd

# Crear el dataframe
datos = [ ['Juan',4.5], ['Pedro',8.9], ['Estefania',1.4], ['Ana',5.6], ['Esteban',7.8]]
columnas = ['Nombre', 'Nota']
indices = list(range(len(datos)))
df = pd.DataFrame(data=datos, columns=columnas, index=indices)
print(df)

# Propiedades o atributos utiles
print("Info:", df.info)
print("shape:", df.shape) # (5, 2)
print("size:", df.size) # 10
print("Nombres de las columnas:", df.columns) # Index(['Nombre', 'Nota'], dtype='str')
print("Indices:", df.index) # Index([0, 1, 2, 3, 4], dtype='int64')

# Accedemos a los datos de una columna
print(df['Nota'])

# Accedemos a los datos de una fila por indice
print(df.loc[2]) # datos de Estefania.    loc[indice de la fila]

# Accedemos a un determinado valor
print(df.iloc[4,1]) # la nota de Esteban.  iloc[indice_fila, indice_columna].  siempre empiezan en 0

# Filtrar por Esteban y mostrar su nota
# df[filtro][columna]
print(df[ df['Nombre']=='Esteban' ] ['Nota'] )

# Agregar nueva columna
resultado = ['Suspenso','Aprobado','Suspenso','Aprobado','Aprobado']
df.insert(loc=1, column="Resultado", value=resultado) # loc=1 posicion de la columna y el resto se desplaza
print(df)

# Agrupar por columna
print(df.groupby('Resultado').size()) # muestra solo el resultado
print(df.groupby('Resultado').count()) # muestra el resultado con las 2 columnas

# Eliminar
# drop genera nuevo dataframe
df = df.drop(['Resultado'], axis=1) # axis=1 borro columnas
print(df)

df = df.drop(4 ,axis=0) # axis=0 borro la fila con indice 4
print(df)
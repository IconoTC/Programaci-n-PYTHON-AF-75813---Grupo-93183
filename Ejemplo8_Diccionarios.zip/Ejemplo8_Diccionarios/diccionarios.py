# Diccionarios: los elementos son clave:valor
# Son colecciones mutables, permiten modificaciones
# No tenemos indices, se accede a través de la clave
# A partir de 3.7 se garantiza el orden de entrada
# Las claves no se pueden repetir, se sobreescribe el valor
# Los valores si se pueden repetir
# Se crean con {}

# Si repito la clave, se sobreescribe el valor
alumnos = {'Juan':6.4, 'Maria':8.3, 'Adolfo':7.1, 'Maria':9.3}
print(alumnos)
print(type(alumnos)) # <class 'dict'>

# Crear un diccionario vacio
vacio = {}
vacio = dict() # Invocamos al constructor de la clase dict

# Mostrar las claves: nombres de los alumnos
print(alumnos.keys()) # dict_keys(['Juan', 'Maria', 'Adolfo'])

# Mostrar los values: notas de los alumnos
print(alumnos.values()) # dict_values([6.4, 9.3, 7.1])

# Mostrar los items
print(alumnos.items()) # dict_items([('Juan', 6.4), ('Maria', 9.3), ('Adolfo', 7.1)])

# Operadores de pertenencia: in y not in
print("Maria" in alumnos)

# Longitud
print("Longitud:", len(alumnos))
print("Longitud:", alumnos.__len__())

# Acceso a los elementos por clave
print("Nota de Juan:", alumnos['Juan'])
#print("Nota de Juan:", alumnos['Juannnnnnnn']) # KeyError: 'Juannnnnnnn'

print("Nota de Juan:", alumnos.get('Juan'))
print("Nota de Juan:", alumnos.get('Juannnnnnnnn')) # None

# Borrar un elemento
#del alumnos['Adolfooooooooo'] # KeyError: 'Adolfooooooooo'
del alumnos['Adolfo']
print(alumnos)

# Agregar nuevo elemento
alumnos['Pepito'] = 3.5
print(alumnos)

# Otra forma de agregar elementos al diccionario
alumnos.update({'Tomas':8})
print(alumnos)

# Modificar el valor de un elemento
alumnos['Pepito'] = 5
print(alumnos)

# Otra forma de eliminar un elemento
alumnos.__delitem__('Tomas')
print(alumnos)

# Recorrer un diccionario
for alum in alumnos:  # solo me devuelve las claves
    print(alum, alumnos[alum])
    
for alum in alumnos.items():  # cada alum es una tupla
    print(alum[0], alum[1])  # Las tuplas son colecciones ordenadas, con indice
    
for nombre, nota in alumnos.items():
    print(nombre, nota)
    
# Otras formas de crear diccionarios
#alumnos = dict(Juan=6.4, Maria=8.3, Adolfo=7.1, Maria=9.3) # SyntaxError: keyword argument repeated: Maria
alumnos = dict(Juan=6.4, Maria=8.3, Adolfo=7.1)
print(alumnos)
alumnos = dict( [('Juan',6.4), ("Maria",8.3), ('Adolfo',7.1)] )
print(alumnos)
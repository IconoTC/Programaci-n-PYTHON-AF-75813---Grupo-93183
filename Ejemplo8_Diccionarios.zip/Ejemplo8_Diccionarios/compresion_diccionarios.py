# Ejemplo 1
# crear un diccionario donde:
#   - la clave es el indice de la lista
#   - el valor es la vocal
lista = ['a','e','i','o','u']
diccionario = { idx:lista[idx] for idx in range(len(lista))}
print(diccionario)

# Ejemplo 2
# crear un diccionario con numeros del 1 al 5 y sus cuadrados
numeros = { num:num**2  for num in range(1,6)}
print(numeros)
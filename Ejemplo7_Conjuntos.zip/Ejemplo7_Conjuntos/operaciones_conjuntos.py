numeros1 = {1,2,3,4,5,6,7,8,9}
numeros2 = {0,2,4,6,8,10}

# interseccion de conjuntos: elementos comunes en ambos conjuntos
print(numeros1.intersection(numeros2)) # {8, 2, 4, 6}
print(numeros1 & numeros2)

# diferencia de conjuntos: elementos de un conjunto que no estan en el otro
print(numeros1.difference(numeros2)) # {1, 3, 5, 7, 9}
print(numeros1 - numeros2)

# El orden importa
print(numeros2.difference(numeros1)) # {0, 10}
print(numeros2 - numeros1)

# Union de conjuntos: todos los elementos de ambos sin repetir los comunes
print(numeros1.union(numeros2)) # {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
print(numeros1 | numeros2)

# Diferencia simetrica de conjuntos: la union - la interseccion
print(numeros1.symmetric_difference(numeros2)) # {0, 1, 3, 5, 7, 9, 10}
print(numeros1 ^ numeros2) 

''' hasta ahora las operaciones que hemos visto no modifican los conjuntos, pero las siguientes si los modifican '''
# modificar con diferencia de conjuntos: borra todos los elementos de un conjunto que estan en el otro
# Aqui el orden importa
numeros1.difference_update(numeros2)
numeros1 -= numeros2
print(numeros1) # {1, 3, 5, 7, 9}
print(numeros2) # {0, 2, 4, 6, 8, 10}

# modificar con union de conjuntos: modifica el conjunto con todos los alementos de ambos, sin repetir los comunes
# Aqui el orden importa
numeros1.update(numeros2)
numeros1 |= numeros2
print(numeros1) # {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
print(numeros2) # {0, 2, 4, 6, 8, 10}
# Conjuntos: colecciones sin orden (no tenemos indices)
# No permite elementos duplicados, los ignora
# No se garantiza el orden de entrada de los elementos
# Los elementos pueden ser de diferente tipo
# Son colecciones mutables, permite modificaciones
# Se crean con {}
# IMPORTANTE: conjunto = {} lo interpreta como diccionario

frutas = {'manzana', 'naranja', 'pera', 'naranja', 'platano'}
print(frutas)
print(type(frutas)) # <class 'set'>

# Conjunto vacio
conjunto = {}
print(type(conjunto)) # <class 'dict'>
conjunto = set() # Llamo al constructor de la clase set
print(type(conjunto)) # <class 'set'>

# Agregar un elemento al conjunto
frutas.add("fresa")
print(frutas)

# Eliminar elemento
frutas.remove('platano')
print(frutas)

#frutas.remove('platanooooooooooooo') # KeyError: 'platanooooooooooooo'

# Longitud
print("Longitud:", len(frutas))
print("Longitud:", frutas.__len__())

# Recorrer el conjunto solo por item
for item in frutas:
    print(item, end=" ")
print()

# Copiar un conjunto en otro
otro = frutas.copy()
print(otro)

# Operadores de pertenencia
print('fresa' in frutas) # True
print('melocoton' in frutas) # False
print('melocoton' not in frutas) # True

# Borrar todos los elementos
otro.clear()
print(otro)

# convertir un conjunto en lista
lista = list(frutas)
print(lista)

# convertir un conjunto en tupla
tupla = tuple(frutas)
print(tupla)

# convertir una lista en conjunto
conjunto = set(lista)
print(conjunto)

# convertir una tupla en conjunto
conjunto = set(tupla)
print(conjunto)
''' Crear la BBDD y la tabla '''

import sqlite3

# Crear la BBDD
# Al abrir la conexion a la BBDD, si no existe la crea
conexion = sqlite3.connect("Ejemplo14_BBDD_Sqlite/tienda.db")

# Obtener el cursor, necesario para ejecutar querys y recoger resultados
cursor = conexion.cursor()

# Crear la tabla PRODUCTOS
cursor.execute("CREATE TABLE PRODUCTOS (id INTEGER PRIMARY KEY, descripcion TEXT, precio REAL)")

# IMPORTANTE EL COMMIT
conexion.commit()

# cerrar la conexion
conexion.close()
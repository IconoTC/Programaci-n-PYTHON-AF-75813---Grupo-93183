'''
    Solicitar el pw al usuario hasta que adivine que es "curso"
    Solo tiene 3 intentos
    Cada vez que falle, mostrar un mensaje con los intentos que quedan
    
    break; da por terminado el bucle
    continue; da por terminada esa iteraccion y pasa a la siguiente
'''

intentos = 1
while intentos <= 3:
    pw = input("Introduce pw: ")
    if pw == 'curso':
        print("Has acertado")
        break
    else:
        print("PW incorrecto, te quedan", 3-intentos, "intentos")
    intentos += 1
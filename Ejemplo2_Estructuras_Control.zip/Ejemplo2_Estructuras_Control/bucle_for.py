nombres = ['Luis', 'Jorge', 'Maria', 'Laura', 'Pedro']

for elemento in nombres:
    print(elemento, end=" ")
print()

''' rangos '''
# range(start,end,step)   el ultimo no esta incluido
# Mostrar los numeros del 0 al 9
for numero in range(10):   # Rango va de 0 hasta num-1
    print(numero, end=" ")
print()

# Mostrar los numeros del 1 al 10
for numero in range(1, 11):   # Rango va de 1 hasta num-1
    print(numero, end=" ")
print()

# Mostrar los numeros del 0 al 10 de 2 en 2
for numero in range(0, 11, 2):   
    print(numero, end=" ")
print()

# Mostrar los numeros del 10 al 1
for numero in range(10, 0, -1):   
    print(numero, end=" ")
print()

# Mostrar los numeros del 10 al 0 de 2 en 2
for numero in range(10, -1, -2):   
    print(numero, end=" ")
print()

# Mostrar los elementos de la lista por indice
for idx in range(len(nombres)):  # Rango de 0 a 4
    print(nombres[idx], end=" ")
print()

# EJERCICIO: sumar los numeros que estan en un indice par
lista = [3,2,8,5,1,9,7]
suma = 0
for idx in range(len(lista)):
    if idx % 2 == 0:
        suma += lista[idx]
print("Suma:", suma)

suma = 0
for idx in range(0,len(lista),2):
    suma += lista[idx]
print("Suma:", suma)
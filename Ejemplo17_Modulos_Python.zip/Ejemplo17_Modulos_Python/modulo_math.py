# https://python-docs-es.readthedocs.io/es/3.14/library/math.html#module-math

import math

print("PI:", math.pi)
print("E:", math.e)

print("Seno:", math.sin(math.radians(90)))
print("Coseno:", math.cos(math.radians(90)))

print("log base 10:", math.log(12345.678, 10))
print("log base 10:", math.log10(12345.678))
print("log base 2:", math.log(12345.678, 2))
print("log base 2:", math.log2(12345.678))

print("2 elevado a 8:", math.pow(2,8)) # float
print("2 elevado a 8:", 2 ** 8) # int
print("e elevado a 8:", math.exp(8))

print("factorial de 4:", math.factorial(4))

print("redondeo al alza 3.89", math.ceil(3.89)) # 4
print("redondeo al alza 3.19", math.ceil(3.19)) # 4

print("redondeo al alza 3.89", math.ceil(-3.89)) # -3
print("redondeo al alza 3.19", math.ceil(-3.19)) # -3

print("redondeo a la baja 3.89", math.floor(3.89)) # 3
print("redondeo a la baja 3.19", math.floor(3.19)) # 3

print("redondeo a la baja -3.89", math.floor(-3.89)) # -4
print("redondeo a la baja -3.19", math.floor(-3.19)) # -4

print("truncar 3.89", math.trunc(3.89)) # 3
print("truncar 3.19", math.trunc(3.19)) # 3
print("truncar -3.89", math.trunc(-3.89)) # -3
print("truncar -3.19", math.trunc(-3.19)) # -3

# https://python-docs-es.readthedocs.io/es/3.14/library/calendar.html#module-calendar

import calendar
import locale

# Mostrar el calendario 2026
print(calendar.calendar(2026, m=4)) # 4 meses por fila

# Mostrar el calendario de Marzo de 2026
print(calendar.month(2026, 3))

# Calendario queremos que comience en domingo
calendar.setfirstweekday(6) # lunes es 0
print(calendar.month(2026, 3))

# Saber si un año es bisiesto
print("2024 es bisiesto?", calendar.isleap(2024)) # True
print("2025 es bisiesto?", calendar.isleap(2025)) # False

# Los dias de la semana
print(calendar.weekheader(1))
print(calendar.weekheader(2))
print(calendar.weekheader(3))
print(calendar.weekheader(4)) # El maximo que muestra es con 3 letras

# A partir del modulo locale podemos poner el calendario en Español
locale_es = locale.setlocale(locale.LC_ALL, "es_ES")
calendario_es = calendar.LocaleTextCalendar(locale=locale_es)
print(calendario_es.formatmonth(2026,3))
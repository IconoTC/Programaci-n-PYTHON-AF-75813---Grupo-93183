# https://python-docs-es.readthedocs.io/es/3.14/library/random.html#module-random

import random

# generar un numero aleatorio entre 0 y 1 (pero sin llegar a 1)
print(random.random())

# generar un numero aleatorio entero entre un rango de numeros (el ultimo no esta incluido)
print("Numero entre 0 y 50:", random.randrange(0,50))
print("Numero entre 10 y 50:", random.randrange(10,50))
print("Numero par entre 10 y 50:", random.randrange(10,50,2))

# randint (si incluye el ultimo)
print("Numero entre 0 y 10:", random.randint(0,10))

# con un bucle sacar 5 numeros aleatorios entre 1 y 6
for item in range(5):
    print("Aleatorio:", random.randint(1,6))
    
# Los metodos randrange y randint pueden devolver numeros repetidos
# Generar numeros aleatorios sin duplicados
# choice: retorna UNO aleatorio de la secuencia pasada como argumento (lista, tupla)
# sample: retorna el numero indicado de aleatorios de la secuencia pasada como argumento (lista, tupla)
print("choice:", random.choice([1,2,3,4,5,6]))
print("choice:", random.choice((1,2,3,4,5,6)))
print("sample:", random.sample([1,2,3,4,5,6], 5))
print("sample:", random.sample((1,2,3,4,5,6), 5))
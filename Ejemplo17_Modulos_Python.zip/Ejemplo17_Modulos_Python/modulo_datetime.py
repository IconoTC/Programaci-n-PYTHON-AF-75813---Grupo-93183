# https://python-docs-es.readthedocs.io/es/3.14/library/datetime.html#module-datetime

import datetime

hoy = datetime.date(2026,3,5)
print(hoy)
print("Año:", hoy.year)
print("Mes:", hoy.month)
print("Dia:", hoy.day)

# Formato personalizado
# https://python-docs-es.readthedocs.io/es/3.14/library/datetime.html#format-codes
print(hoy.strftime('%d/%m/%Y'))

print("Dia de semana:", hoy.weekday()) # el lunes es 0
print("Dia de semana:", hoy.isoweekday()) # el lunes es 1

# Fecha y hora del sistema
print("Fecha y hora actual:", datetime.datetime.now())

# Modificar fechas
print("Mañana:", hoy.replace(day=6).strftime('%d/%m/%Y'))

# Crear un periodo de tiempo
periodo = datetime.timedelta(days=7)
print(hoy + periodo)
print(hoy - periodo)
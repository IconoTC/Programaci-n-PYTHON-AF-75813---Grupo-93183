# La funcion reduce le pasamos una coleccion
# y retorna un solo resultado
# La funcion ha de tener 2 parametros:
#       - el primero actua como acumulador
#       - el segundo es el valor recibido
# Sintaxis: reduce(funcion, coleccion)

''' Para utilizar reduce hay que importarlo '''
from functools import reduce

# Ejemplo 1
numeros = [3,8,5,14,28]

def sumar(acumulador, num):
    # la primera vez que se invoca se le pasan 2 argumentos: 3 y 8
    #print("----------")
    #print("Acumulador:", acumulador, "Num:", num)
    #print("----------")
    return acumulador + num

print("Suma:", reduce(sumar, numeros))


# Ejemplo 2
# utilizando reduce retornar una cadena con todos los nombres en mayusculas separados por " - "
nombres = ['Luis', 'Jorge', 'Maria', 'Laura', 'Pedro']

def concatenar(acumulador, nombre):
    return acumulador.upper()  + " - " + nombre.upper()

print(reduce(concatenar, nombres))

# La funcion filter, se aplica sobre una coleccion donde
# con cada elemento se invoca a otra funcion donde filtramos
# La funcion ha de devolver un valor booleano:
#       - True: pasa el filtro y no lo que damos
#       - False: no pasa el filtro y lo descartamos
# sintaxis: filter(funcion, coleccion)

# Ejemplo 1
numeros = [3,8,5,14,28]

def pares(num):
    if num % 2 == 0:
        return True
    else:
        return False
    # return num % 2 == 0
    
numeros_pares = list(filter(pares, numeros))
print(numeros_pares)
print(numeros) # No se modifica


# Ejemplo 2
alumnos = dict(Juan=3.4, Maria=8.3, Adolfo=7.1, Luis=4.1)

def suspensos(item):
    return item[1] < 5

alumnos_suspensos = dict(filter(suspensos, alumnos.items()))
print(alumnos_suspensos)


# Ejemplo 3
# crear una lista con los menores de edad
from persona import Persona      # Clase
personas = [Persona("Juan",27), Persona("Maria",15), Persona("Pedro",21)]

def menores(persona: Persona):
    return persona.edad < 18

personas_menores = list(filter(menores, personas))
for p in personas_menores:
    print(p)